
Go to the directory where part2.jar file is located then

Enter command: java -jar part2.jar 

 
