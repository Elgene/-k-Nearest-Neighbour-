
Go to the directory where part3.jar file is located then

Enter command: java -jar part3.jar 
