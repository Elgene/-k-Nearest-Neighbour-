
Go to the directory where part1.jar file is located then

Enter command: java -jar part1.jar 

